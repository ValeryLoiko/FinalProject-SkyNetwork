//
//  File.swift
//  SkyNetwork
//
//  Created by Diana on 31/03/2022.
//

import Foundation


class DataUserDefaults {
    
    static let userDefaults = UserDefaults.standard
}

struct SettingsKeys {
    
    static let keyForName = "keyName"
    static let keyForSound = "keySound"
    static let keyForVolume = "keyVolume"
}
