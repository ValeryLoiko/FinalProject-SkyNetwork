//
//  ModelUser.swift
//  SkyNetwork
//
//  Created by Diana on 03/04/2022.
//

import Foundation
import UIKit
import MapKit


class ModelUser {
    
    var users = [[User]]()
    init() {
        setup()
    }
    
    func setup() {
        let man1 = User(name: "Andrey", city: "Grodno", image: UIImage(named: "AndrejR")!, gender: .male, coordinate: CLLocationCoordinate2D(latitude: 53.121748, longitude: 23.122007))
        let man2 = User(name: "Dima", city: "Bialystok", image: UIImage(named: "DimaM")!, gender: .male, coordinate: CLLocationCoordinate2D(latitude: 53.127633756697804, longitude: 23.145461240385142))
        let man3 = User(name: "Liosha", city: "Mosty", image: UIImage(named: "LioshaS")!, gender: .male, coordinate: CLLocationCoordinate2D(latitude:  53.13714986878126, longitude: 23.15342225572913))
        let man4 = User(name: "Pasha", city: "Bialystok", image: UIImage(named: "PashaD")!, gender: .male, coordinate: CLLocationCoordinate2D(latitude: 53.143030845896995, longitude: 23.140145855729383))
        let man5 = User(name: "Pasha", city: "Brusel", image: UIImage(named: "PashaSt")!, gender: .male, coordinate: CLLocationCoordinate2D(latitude: 50.858841517336344, longitude: 4.380726269134909))
        let man6 = User(name: "Sasha", city: "Bialystok", image: UIImage(named: "SashaS")!, gender: .male, coordinate: CLLocationCoordinate2D(latitude: 53.120746030525545, longitude: 23.151047999242266))
        let man7 = User(name: "Sergej", city: "Straubing", image: UIImage(named: "SergejL")!, gender: .male, coordinate: CLLocationCoordinate2D(latitude: 48.87263905736335, longitude: 12.575884811390264))
        let man8 = User(name: "Tadik", city: "Bialystok", image: UIImage(named: "Tadik")!, gender: .male, coordinate: CLLocationCoordinate2D(latitude: 53.123543384848745, longitude: 23.1694954925621))
        
        let manArray = [man1, man2, man3, man4, man5, man6, man7, man8]
        
        let woman1 = User(name: "Dasha", city: "Mosty", image: UIImage(named: "DashaD")!, gender: .female, coordinate: CLLocationCoordinate2D(latitude: 53.41912226132121, longitude: 24.559108369810023))
        let woman2 = User(name: "Dasha", city: "Minsk", image: UIImage(named: "DashaL")!, gender: .female, coordinate: CLLocationCoordinate2D(latitude: 53.20371267099088, longitude: 24.01957536429137))
        let woman3 = User(name: "Diana", city: "Bialystok", image: UIImage(named: "DianaK")!, gender: .female, coordinate: CLLocationCoordinate2D(latitude: 53.1200126873442, longitude: 23.155038775433752))
        let woman4 = User(name: "Diana", city: "Bialystok", image: UIImage(named: "DianaM")!, gender: .female, coordinate: CLLocationCoordinate2D(latitude: 53.13369576644735, longitude: 23.127316088525145))
        let woman5 = User(name: "Julia", city: "Bialystok", image: UIImage(named: "Julia")!, gender: .female, coordinate: CLLocationCoordinate2D(latitude: 53.13880544175257, longitude: 23.11882331766427))
        let woman6 = User(name: "Katia", city: "Warshawa", image: UIImage(named: "KatiaM")!, gender: .female, coordinate: CLLocationCoordinate2D(latitude: 52.214867298508686, longitude: 21.134131071410934))
        let woman7 = User(name: "Katia", city: "Grodno", image: UIImage(named: "KatiaS")!, gender: .female, coordinate: CLLocationCoordinate2D(latitude: 53.67641259736037, longitude: 23.829560726914153))
        
        let womanArray = [woman1, woman2, woman3, woman4, woman5, woman6, woman7]
        
        users.append(manArray)
        users.append(womanArray)
    }
}
