//
//  UsersViewController.swift
//  SkyNetwork
//
//  Created by Diana on 03/04/2022.
//

import UIKit


class UsersViewController: UIViewController {
    
    @IBOutlet weak var avatarImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    
    var user: User!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red:0.63, green:0.59, blue:0.87, alpha:1.0)
        
        nameLabel.text = user.name
        cityLabel.text = user.city
        avatarImage.image = user.image
        
        addBorder()
    }
    
    func addBorder() {
        avatarImage.layer.borderWidth = 3.5
        if user.gender == .male {
            avatarImage.layer.borderColor = UIColor.blue.cgColor
        } else {
            avatarImage.layer.borderColor = UIColor.purple.cgColor
        }
        avatarImage.layer.cornerRadius = avatarImage.frame.width / 2
    }
}
