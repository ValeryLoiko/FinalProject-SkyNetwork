//
//  SettingsTableViewController.swift
//  SkyNetwork
//
//  Created by Diana on 31/03/2022.
//

import UIKit

class SettingsTableViewController: UITableViewController {
    
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var soundSwitch: UISwitch!
    @IBOutlet weak var volumeSlider: UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        loadSettings()
    }
    
    func loadSettings() {
        if let name = DataUserDefaults.userDefaults.string(forKey: SettingsKeys.keyForName) {
            nameField.text = name
        }
        soundSwitch.isOn = DataUserDefaults.userDefaults.bool(forKey: SettingsKeys.keyForSound)
        volumeSlider.value = DataUserDefaults.userDefaults.float(forKey: SettingsKeys.keyForVolume)
    }
    
    @IBAction func changeNameAction(_ sender: UITextField) {
        if (sender.text != nil) {
            DataUserDefaults.userDefaults.set(sender.text!, forKey: SettingsKeys.keyForName)
        }
    }
    
    @IBAction func soundAction(_ sender: UISwitch) {
        DataUserDefaults.userDefaults.set(sender.isOn, forKey: SettingsKeys.keyForSound)
    }
    
    @IBAction func volumeAction(_ sender: UISlider) {
        DataUserDefaults.userDefaults.set(sender.value, forKey: SettingsKeys.keyForVolume)
    }
}
