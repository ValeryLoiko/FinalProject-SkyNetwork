//
//  ImageCollectionViewCell.swift
//  SkyNetwork
//
//  Created by Diana on 24/03/2022.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageCell: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
